Public Hong Kong tourism source snapshots
Retrieved 21 September 2026

These files are copies of government open-data resources related to the study
"When Online Discussion Helps Forecast Hong Kong Tourism." They are not the
complete study dataset and do not reproduce the exact archived analysis panel.
The study's Wisers-supplied topic counts and other provider fields are not in
this archive; public release of those fields requires Wisers' permission.

Files, sources, and SHA-256 hashes:

visitor_arrivals_residence_2026-09-21.json
  Hong Kong Census and Statistics Department, Table 650-80002,
  visitor arrivals by mode of transport and country/region of residence.
  Source: https://www.censtatd.gov.hk/api/get.php?id=650-80002&lang=en&full_series=1
  SHA-256: 70fb56d8140fdfddbedde6a68a6b140c44e6423baf4a3a7aaf7d6e893ceb1050

hotel_occupancy_2026-09-21.csv
  Hong Kong Culture, Sports and Tourism Bureau, monthly hotel occupancy rate.
  Source: https://www.tourism.gov.hk/datagovhk/hotelroomoccupancy/hotel_room_occupancy_rate_monthly_en.csv
  SHA-256: 516cd4831a2955b14881cdd61656eb2a5e1dad06e70c2215c73795f7d45fcd4e

hotel_room_rate_2026-09-21.csv
  Hong Kong Culture, Sports and Tourism Bureau, average achieved hotel room rate.
  Source: https://www.tourism.gov.hk/datagovhk/hotelroomrate/average_achieved_hotel_room_rate_en.csv
  SHA-256: 03cbefcd2ec4b2dde9a5fcae29011f0292eb29045c4667519be8f34e9fd59297

Attribution and reuse:
The data originate from the Government of the Hong Kong Special Administrative
Region and the named data providers, who are acknowledged as the owners of
intellectual property in the data. Reuse is subject to the DATA.GOV.HK Terms
and Conditions: https://data.gov.hk/en/terms-and-conditions .
